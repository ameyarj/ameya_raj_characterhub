<script setup>
import MovieDetails from './components/MovieDetails.vue'
</script>

<template>
  
    <MovieDetails />

</template>
